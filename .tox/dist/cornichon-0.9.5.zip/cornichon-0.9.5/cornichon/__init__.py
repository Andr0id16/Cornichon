import os
import os.path
import sys
direc = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, direc)
from .cornichon import *
name = "cornichon"
